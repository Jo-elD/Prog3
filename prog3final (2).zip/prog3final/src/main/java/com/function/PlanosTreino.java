package com.function;

import java.util.List;

public class PlanosTreino {
    private String id;
    private String nome;
    private String descricao;
    private String duracao;
    private String nivelDificuldade;
    private String objetivo;
    private List<String> exercicios;

    // Getters e Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }

    public String getDuracao() { return duracao; }
    public void setDuracao(String duracao) { this.duracao = duracao; }

    public String getNivelDificuldade() { return nivelDificuldade; }
    public void setNivelDificuldade(String nivelDificuldade) { this.nivelDificuldade = nivelDificuldade; }

    public String getObjetivo() { return objetivo; }
    public void setObjetivo(String objetivo) { this.objetivo = objetivo; }

    public List<String> getExercicios() { return exercicios; }
    public void setExercicios(List<String> exercicios) { this.exercicios = exercicios; }
}