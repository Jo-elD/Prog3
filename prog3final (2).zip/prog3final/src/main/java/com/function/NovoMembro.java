package com.function;
 
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.HttpMethod;
import com.microsoft.azure.functions.HttpRequestMessage;
import com.microsoft.azure.functions.HttpResponseMessage;
import com.microsoft.azure.functions.HttpStatus;
import com.microsoft.azure.functions.OutputBinding;
import com.microsoft.azure.functions.annotation.AuthorizationLevel;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.HttpTrigger;
import com.microsoft.azure.functions.annotation.CosmosDBOutput;
 
/**
 * Azure Functions com gatilho HTTP.
 */
public class NovoMembro {
    /**
     * Este exemplo demonstra uma função HTTP que será acionada ao enviar uma
     * requisição HTTP
     * para o endpoint "/api/InsertCarroFunction".
     */
    @FunctionName("NovoMembro")
    public HttpResponseMessage run(
            @HttpTrigger(
                name = "req",
                methods = { HttpMethod.POST }, 
                authLevel = AuthorizationLevel.ANONYMOUS) 
                HttpRequestMessage<Membro> request,

            @CosmosDBOutput(
                name = "membroOutput", 
                databaseName = "prog3-final", 
                containerName = "membros", 
                connection = "CosmosDBConnection") 
                OutputBinding<Membro> outputItem,
            final ExecutionContext context) {
        context.getLogger().info("Java HTTP trigger processed a request.");
        // Obter o objeto Carro do corpo da requisição
        Membro membro = request.getBody();

        // Validação básica
        if (membro.getId() == null || membro.getNome() == null || membro.getIdade() == null || membro.getPagamento() == null) {
            return request.createResponseBuilder(HttpStatus.BAD_REQUEST)
                    .body("Por favor, preencha todos os campos do plano de treino.").build();
        } else {
            // Inserir o objeto PlanosTreino no CosmosDB
            outputItem.setValue(membro);
            
            // Responder que a inserção foi bem-sucedida
            return request.createResponseBuilder(HttpStatus.OK).body("Plano criado com sucesso.").build();
        }
    }
}