package com.function;
 
import com.microsoft.azure.functions.annotation.*;
import com.microsoft.azure.functions.*;
import java.util.Optional;
 
public class UpdatePlano {
 
    @FunctionName("UpdatePlano")
    public HttpResponseMessage run(
            @HttpTrigger(
            name = "req", 
            methods = { HttpMethod.PUT }, 
            authLevel = AuthorizationLevel.ANONYMOUS) 
            HttpRequestMessage<Optional<PlanosTreino>> request,

            @CosmosDBInput(
            name = "atualPlano", 
            databaseName = "prog3-final", 
            containerName = "planosdetreino", 
            id = "{Query.id}", 
            partitionKey = "{Query.id}", 
            connection = "CosmosDBConnection") PlanosTreino atualPlano,

            @CosmosDBOutput(
            name = "planoOutput", 
            databaseName = "prog3-final", 
            containerName = "planosdetreino", 
            connection = "CosmosDBConnection") 
            OutputBinding<PlanosTreino> outputPlano,
            final ExecutionContext context) {
 
        context.getLogger().info("Java HTTP trigger processed a request to update a Plano.");
 
        if (atualPlano == null) {
            return request.createResponseBuilder(HttpStatus.NOT_FOUND).body("Plano não encontrado.").build();
        }
 
 
        PlanosTreino updatedPlano = request.getBody().orElse(null);
 
        if (updatedPlano == null) {
                return request.createResponseBuilder(HttpStatus.BAD_REQUEST).body("Dados do Plano inválidos.").build();
        }
 
        // Atualiza os campos do carro existente com os novos valores
        atualPlano.setNome(updatedPlano.getNome());
        atualPlano.setDescricao(updatedPlano.getDescricao());
        atualPlano.setDuracao(updatedPlano.getDuracao());
        atualPlano.setNivelDificuldade(updatedPlano.getNivelDificuldade());
        atualPlano.setObjetivo(updatedPlano.getObjetivo());
        atualPlano.setExercicios(updatedPlano.getExercicios());
 
        // Salva o carro atualizado no Cosmos DB
        outputPlano.setValue(atualPlano);
 
        return request.createResponseBuilder(HttpStatus.OK).body(atualPlano).build();
    }
}