package com.function;

import com.azure.cosmos.*;
import com.azure.cosmos.models.CosmosItemRequestOptions;
import com.azure.cosmos.models.CosmosItemResponse;
import com.azure.cosmos.models.PartitionKey;
import com.microsoft.azure.functions.annotation.*;
import com.microsoft.azure.functions.*;

import java.util.Optional;

public class DeleteMembro {
    @FunctionName("DeleteMembro")
    public HttpResponseMessage run(
        @HttpTrigger(
        name = "req", 
        methods = {HttpMethod.DELETE}, 
        route = "membro/{id}", 
        authLevel = AuthorizationLevel.ANONYMOUS)
        HttpRequestMessage<Optional<String>> request,
        @BindingName("id") String id,
        final ExecutionContext context) {

        context.getLogger().info("Java HTTP trigger processed a request.");

        // Validar o ID
        String connectionString = System.getenv("CosmosDBConnection");

        String[] parts = connectionString.split(";");
        String endpoint = "";
        String key = "";

        for (String part : parts) {
            if (part.startsWith("AccountEndpoint=")) {
                endpoint = part.replace("AccountEndpoint=", "");
            } else if (part.startsWith("AccountKey=")) {
                key = part.replace("AccountKey=", "");
            }
}

        CosmosClient client = new CosmosClientBuilder()
            .endpoint(endpoint)
            .key(key)
            .buildClient();


        CosmosContainer container = client.getDatabase("prog3-final").getContainer("membros");

        try {
            CosmosItemResponse<?> response = container.deleteItem(id, new PartitionKey(id), new CosmosItemRequestOptions());
            context.getLogger().info("Deleted item: " + id + " with status code: " + response.getStatusCode());
            return request.createResponseBuilder(HttpStatus.OK).body("Membro deleted.").build();
        } catch (CosmosException e) {
            context.getLogger().info("Delete item failed with: " + e);
            return request.createResponseBuilder(HttpStatus.INTERNAL_SERVER_ERROR).body("Error deleting membro.").build();
        }
    }
}