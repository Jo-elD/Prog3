package com.function;
 
import com.microsoft.azure.functions.annotation.*;
import com.microsoft.azure.functions.*;
import java.util.*;
 
public class GetAllPlanos {
    @FunctionName("GetAllPlanos")
    public HttpResponseMessage run(
            @HttpTrigger(
            name = "req", 
            methods = { HttpMethod.GET }, 
            authLevel = AuthorizationLevel.ANONYMOUS) 
            HttpRequestMessage<Optional<String>> request,
            
            @CosmosDBInput(
            name = "plano", 
            databaseName = "prog3-final", 
            containerName = "planosdetreino", 
            connection = "CosmosDBConnection", 
            sqlQuery = "SELECT * FROM c") List<PlanosTreino> plano,
            final ExecutionContext context) {
        context.getLogger().info("Java HTTP trigger processed a request.");
        if (plano == null || plano.size() == 0) {
            return request.createResponseBuilder(HttpStatus.NOT_FOUND).build();
        }
        // Responder com a lista de carros
        return request.createResponseBuilder(HttpStatus.OK).body(plano).build();
    }
}