package com.function;
 
import com.microsoft.azure.functions.*;
import com.microsoft.azure.functions.annotation.*;
import java.util.Optional;
import com.google.gson.Gson;
 
public class GetPlano {
    @FunctionName("ObterPlano")
    public HttpResponseMessage run(
            @HttpTrigger(name = "req", 
            methods = { HttpMethod.GET }, 
            authLevel = AuthorizationLevel.ANONYMOUS) 
            HttpRequestMessage<Optional<String>> request,

            @CosmosDBInput(
            name = "planoInput", 
            databaseName = "prog3-final", 
            containerName = "planosdetreino", 
            id = "{Query.id}", 
            partitionKey = "{Query.id}", 
            connection = "CosmosDBConnection") 
            PlanosTreino plano,

            final ExecutionContext context) {
        context.getLogger().info("Java HTTP trigger processed a request.");
        Gson gson = new Gson();
        String planoJson = gson.toJson(plano);
        if (plano == null) {
            return request.createResponseBuilder(HttpStatus.NOT_FOUND).body("Plano não encontrado.").build();
        } else {
            return request.createResponseBuilder(HttpStatus.OK)
                    .header("Content-Type", "application/json")
                    .body(planoJson)
                    .build();
        }
    }
}